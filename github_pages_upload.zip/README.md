# GitHub Pages Site

This folder is ready to upload to a **new GitHub repository** and publish with **GitHub Pages**.

## Quick Publish Steps
1. Create a new repo at https://github.com/new (Public).
2. Click **Add file → Upload files** and drag-drop *all files in this folder*.
3. Commit changes.
4. Go to **Settings → Pages** and set **Source** to **Deploy from a branch**, branch **main**, folder **/** (root).
5. Wait ~1–2 minutes. Your site will be at: `https://<your-username>.github.io/<repo-name>/`

## Notes
- Main page: **Index.html**
- Keep CSS/JS/images in the same relative paths.
- To change the homepage, edit `index.html`.
