# GitHub Pages Ready (database → index)

Upload these files to the root of your `database` repo to publish on GitHub Pages.

## Steps
1. Open https://github.com/nadianajem002-png/database
2. **Add file → Upload files** → drag-drop everything from this ZIP (keep at root).
3. Commit.
4. **Settings → Pages** → Source: Deploy from a branch, Branch: main, Folder: /(root).
5. Visit https://nadianajem002-png.github.io/database/

What's inside:
- `index.html` (copied from your `database.html` if present, or from your first HTML file)
- `database.html` (original kept, if present)
- `.nojekyll` (so assets in underscored folders serve correctly)
- your assets unchanged
